import React from 'react';
import {useState,useEffect} from 'react';
import Apartlist from './Apartlist';
import Nav  from './Nav';
const Home = () => {


  




  return (
    <div>
      <Apartlist/>
    </div>
  );
}

export default Home;
